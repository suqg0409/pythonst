export { UEditorComponent } from './src/ueditor.component';
export { UEditorConfig } from './src/ueditor.config';
export * from './src/ueditor.module';
